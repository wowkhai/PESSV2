-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2020 at 08:06 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `khairul_pessdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `dispatch`
--

CREATE TABLE `dispatch` (
  `incidentId` int(11) NOT NULL,
  `patrolcarId` varchar(10) CHARACTER SET latin1 NOT NULL,
  `timeDispatched` datetime NOT NULL,
  `timeArrived` datetime DEFAULT NULL,
  `timeCompleted` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dispatch`
--

INSERT INTO `dispatch` (`incidentId`, `patrolcarId`, `timeDispatched`, `timeArrived`, `timeCompleted`) VALUES
(17, 'QX1A', '2020-05-08 13:26:30', '2020-05-08 15:57:31', NULL),
(18, 'QX5D', '2020-05-08 14:50:48', NULL, NULL),
(19, 'QX10J', '2020-05-08 15:20:33', NULL, NULL),
(20, 'QX1234A', '2020-05-08 15:23:39', '2020-06-24 13:57:31', '2020-06-24 13:58:53'),
(21, 'QX2020K ', '2020-05-08 16:06:00', '2020-05-08 16:06:09', '2020-06-17 10:50:32'),
(22, 'QX9H', '2020-05-08 16:18:55', NULL, NULL),
(23, 'QX2A', '2020-05-08 16:22:03', '2020-05-08 16:22:22', '2020-05-08 16:26:06'),
(24, 'QX4401K', '2020-05-08 16:45:43', '2020-05-08 16:50:36', '2020-05-08 16:53:52'),
(25, 'QX2020K ', '2020-06-17 10:44:55', '2020-06-17 10:49:41', '2020-06-17 10:50:32'),
(26, 'QX1234A', '2020-06-24 13:49:26', '2020-06-24 13:57:31', '2020-06-24 13:58:53');

-- --------------------------------------------------------

--
-- Table structure for table `incident`
--

CREATE TABLE `incident` (
  `incidentId` int(11) NOT NULL,
  `callerName` varchar(30) CHARACTER SET latin1 NOT NULL,
  `phoneNumber` varchar(10) CHARACTER SET latin1 NOT NULL,
  `incidentTypeId` varchar(3) CHARACTER SET latin1 NOT NULL,
  `incidentLocation` varchar(50) CHARACTER SET latin1 NOT NULL,
  `incidentDesc` varchar(100) CHARACTER SET latin1 NOT NULL,
  `incidentStatusId` varchar(1) CHARACTER SET latin1 NOT NULL,
  `timeCalled` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `incident`
--

INSERT INTO `incident` (`incidentId`, `callerName`, `phoneNumber`, `incidentTypeId`, `incidentLocation`, `incidentDesc`, `incidentStatusId`, `timeCalled`) VALUES
(17, 'Khairul', '96371767', '013', 'Jurong West', 'Someone broke into the ...', '2', '2020-05-08 05:26:30'),
(18, 'Ali', '91234567', '012', 'Ang Mo Kio', 'Riot at Ang Mo Kio Street 21', '2', '2020-05-08 06:50:48'),
(19, 'Khairul', '91242345', '012', 'Jurong West', 'Riot at..', '2', '2020-05-08 07:20:33'),
(20, 'Khairul', '96371767', '014', 'Jurong West', 'test', '2', '2020-05-08 07:23:39'),
(21, 'Bala', '91242345', '001', 'Pasir Ris', 'My house is on fire', '2', '2020-05-08 08:06:00'),
(22, 'Khairul', '90909090', '016', 'Marina Bay', 'CBD Accident', '2', '2020-05-08 08:18:55'),
(23, 'Khairul', '98765432', '015', 'Jurong West', 'A tree has fallen and it can\'t get up.', '3', '2020-05-08 08:22:03'),
(24, 'John Tan', '91236578', '016', 'Beach Road', 'Two cars have collided at the road and It seems that they are not moving!', '3', '2020-05-08 08:45:43'),
(25, 'kim', '8765432199', '001', 'AMK', 'AMK blk 876 on fire', '3', '2020-06-17 02:44:55'),
(26, 'Khairul', '90123456', '001', 'Jurong West Street 00', 'House fire @ Jurong West Block 000', '3', '2020-06-24 05:49:26');

-- --------------------------------------------------------

--
-- Table structure for table `incidenttype`
--

CREATE TABLE `incidenttype` (
  `incidentTypeId` varchar(3) CHARACTER SET latin1 NOT NULL,
  `incidentTypeDesc` varchar(20) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `incidenttype`
--

INSERT INTO `incidenttype` (`incidentTypeId`, `incidentTypeDesc`) VALUES
('001', 'House Fire'),
('002', 'Industrial Fire'),
('011', 'Loan Shark'),
('012', 'Riot'),
('013', 'Burglary'),
('014', 'Domestic Violence'),
('015', 'Fallen Tree'),
('016', 'Traffic Accident');

-- --------------------------------------------------------

--
-- Table structure for table `incident_status`
--

CREATE TABLE `incident_status` (
  `statusId` varchar(1) CHARACTER SET latin1 NOT NULL,
  `statusDesc` varchar(20) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `incident_status`
--

INSERT INTO `incident_status` (`statusId`, `statusDesc`) VALUES
('1', 'Pending'),
('2', 'Dispatched'),
('3', 'Completed'),
('4', 'Duplicate');

-- --------------------------------------------------------

--
-- Table structure for table `patrolcar`
--

CREATE TABLE `patrolcar` (
  `patrolcarId` varchar(10) CHARACTER SET latin1 NOT NULL,
  `patrolcarStatusId` varchar(1) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patrolcar`
--

INSERT INTO `patrolcar` (`patrolcarId`, `patrolcarStatusId`) VALUES
('QX10J', '2'),
('QX1234A', '3'),
('QX1A', '2'),
('QX2020K ', '3'),
('QX2A', '3'),
('QX3B', '3'),
('QX4401K', '3'),
('QX4C', '3'),
('QX5D', '2'),
('QX6E', '2'),
('QX7F', '3'),
('QX8G', '2'),
('QX9012F', '3'),
('QX9H', '3');

-- --------------------------------------------------------

--
-- Table structure for table `patrolcar_status`
--

CREATE TABLE `patrolcar_status` (
  `statusId` varchar(1) CHARACTER SET latin1 NOT NULL,
  `statusDesc` varchar(20) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patrolcar_status`
--

INSERT INTO `patrolcar_status` (`statusId`, `statusDesc`) VALUES
('1', 'Dispatched'),
('2', 'On-Patrol'),
('3', 'Available'),
('4', 'Arrived');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dispatch`
--
ALTER TABLE `dispatch`
  ADD PRIMARY KEY (`incidentId`,`patrolcarId`);

--
-- Indexes for table `incident`
--
ALTER TABLE `incident`
  ADD PRIMARY KEY (`incidentId`);

--
-- Indexes for table `incidenttype`
--
ALTER TABLE `incidenttype`
  ADD PRIMARY KEY (`incidentTypeId`);

--
-- Indexes for table `incident_status`
--
ALTER TABLE `incident_status`
  ADD PRIMARY KEY (`statusId`);

--
-- Indexes for table `patrolcar`
--
ALTER TABLE `patrolcar`
  ADD PRIMARY KEY (`patrolcarId`);

--
-- Indexes for table `patrolcar_status`
--
ALTER TABLE `patrolcar_status`
  ADD PRIMARY KEY (`statusId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `incident`
--
ALTER TABLE `incident`
  MODIFY `incidentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
