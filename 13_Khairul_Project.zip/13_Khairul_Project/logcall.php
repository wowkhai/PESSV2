<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Police Emergency Service System</title>
    
<!-- CSS for StepbyStep Menu -->
<style> 
    
a.logcallcircle {
    width: 50px;
    height: 50px;
    font-weight: bold;
    border-radius: 100px;
    display: inline-block;
    line-height: 50px;
    border-style: solid;
    border-color: #8BC34A;
    color: #8BC34A;
    }

a.dispatchcircle {
    width: 50px;
    height: 50px;
    font-weight: bold;
    border-radius: 100px;
    display: inline-block;
    line-height: 50px;
    border-style: solid;
    border-color: #ECE5E5;
    color: #ECE5E5;
}

a.updatecircle {
    width: 50px;
    height: 50px;
    font-weight: bold;
    border-radius: 100px;
    display: inline-block;
    line-height: 50px;
    border-style: solid;
    border-color: #ECE5E5;
    color: #ECE5E5;
}

a.historycircle {
    width: 50px;
    height: 50px;
    font-weight: bold;
    border-radius: 100px;
    display: inline-block;
    line-height: 50px;
    border-style: solid;
    border-color: #ECE5E5;
    color: #ECE5E5;
}
</style>
	<link href="stylesheet.css" rel="stylesheet" type="text/css"> <!-- CSS Stylesheet -->
</head>
<body>
<script>
function form()
{ 

	// Caller's Name Validation
	var x = document.forms["frmLogCall"]["callerName"].value;
	var Name = document.getElementById("callerName").value;
	var contactNo = document.getElementById("contactNo").value;
	var location = document.getElementById("location").value;
	var incidentDesc = document.getElementById("incidentDesc").value;
	
	// Name Validation Empty Input Check
    if (x==null || x=="")
    {
        alert("Enter a Valid Name");
        return false;
    }
	
	// Name Validation Alphabetical Check
	if (!x.match(/^[a-zA-Z]+$/)) 
	{
        alert("Enter a Valid Alphabetical Name");
        return false;
	}

	// Contact No Validation
	if(isNaN(contactNo) || contactNo.length != 8) 
	{
    	alert("Enter a valid Phone Number.");
    	return false;
  	} 
	
	if (!contactNo.match(/[6|8|9]\d{7}|\+65[6|8|9]\d{7}|\+65\s[6|8|9]\d{7}/g))
		{
			alert("Enter a Valid Phone Number that starts with 6,8 or 9.");
        	return false;
		}
	
	
	// Location Empty Input Check
    if (location == null || location == "")
    {
        alert("Enter a Valid Location");
        return false;
    }
	
	// Incident Description Empty Input Check
    if (incidentDesc == null || incidentDesc == "")
    {
        alert("Enter a Valid Incident Description");
        return false;
    }
	
    // add validation codes
}
</script>
    
<!-- 1366px x 750px White Rectangle -->
<div class = "OverallBackground">

<!-- Top Bar -->
<div id = "square"></div>
    
<!-- Navigation Bar (.Navigation) -->
<?php require 'nav.php';?> 

<img src="Media/pessbannerv2.jpg" width="750" alt="PESS Banner"/ id="Center">
<?php require 'db.config.php';

$mysqli = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
	
if ($mysqli->connect_errno)
	{
		die("ERROR - Database connection error: ".$mysqli->connect_errno);
	}

$sql = "SELECT * FROM incidenttype";
	
if (!($stmt = $mysqli->prepare($sql)))
	{
		die("ERROR - Command error: ".$mysqli->errno);
	}
	
if (!$stmt->execute())
	{
		die("ERROR - Unable to run SQL command: ".$stmt->errno);
	}
	
if (!($resultset = $stmt->get_result())) {
	die("ERROR - resultset null: ".$stmt->errno);
}
	$incidentType; 
	
while ($row = $resultset->fetch_assoc()) {
	$incidentType[$row['incidentTypeId']] = $row['incidentTypeDesc'];
}
	
$stmt->close();
	
$resultset->close();
	
$mysqli->close();
	
?>

<div id="squarebottom"></div>
 
<div id="form">
<legend><br>
<br>
</legend>
    <form name="frmLogCall" method="post" action="dispatch.php" onSubmit="return form();">
	<table width="40%" border="0" align="center" cellpadding="4" cellspacing="4">
	<tr>
	<td width="50%"><strong>Caller's Name :</strong></td>
	<td width="50%"><input type="text" name="callerName" id="callerName" placeholder="Khairul N"></td>
	</tr>
	<tr>
	<td width="50%"><strong>Contact No :</strong></td>
	<td width="50%"><input type="text" name="contactNo" id="contactNo" maxlength="8" placeholder="91234567"></td>
	</tr>
	<tr>
	<td width="50%"><strong>Location :</strong></td>
	<td width="50%"><input type="text" name="location" id="location" placeholder="Ang Mo Kio Street 21"></td>
	</tr>
	<tr>
	<td width="50%"><strong>Incident Type :</strong></td>
		<td width="50%"><select name="incidentType" id="incidentType">
		<?php
		foreach($incidentType as $key=> $value) {?>
		<option value="<?php echo $key ?> ">
			<?php echo $value ?> </option>
		<?php } ?>
		</select>
		</td>
	</tr>
	<tr>
	<td width="50%"><strong>Incident Description :</strong></td>
	<td width="50%"><textarea name="incidentDesc" id="incidentDesc" cols="50" rows="5" placeholder="House fire seen at Block 458.."></textarea></td>
	</tr>
		<tr>
		<td> <input type="reset" name="cancelProcess" id="cancelProcess" value="Reset"></td>
		<td> <input type="submit" name="btnProcessCall" id="btnProcessCall" value="Process Call"></td>
		</tr>
    </table>
</form>
</div>

</div>
</body>

</html>