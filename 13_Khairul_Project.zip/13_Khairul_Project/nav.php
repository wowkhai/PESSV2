<div class="status">
<table width="500px" border="0" align="center">

    <tr class="TextCenter">
      <td><a href="logcall.php" class="logcallcircle">1</a></td>
      <td><a href="update.php" class="dispatchcircle">2</a></td>
      <td><a href="#" class="updatecircle">3</a></td>
      <td><a href="#" class="historycircle">4</a></td>
    </tr>
    
    <tr class="TextCenter">
      <td><p><strong>Log Call</strong></p></td>
      <td><p>Update</p></td>
      <td><p>Report</p></td>
      <td><p>History</p></td>
    </tr>
</table>
</div>

